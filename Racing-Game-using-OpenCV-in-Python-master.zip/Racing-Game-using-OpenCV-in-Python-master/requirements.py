openCV
conda
imutils
pyobjc-framework-Quartz